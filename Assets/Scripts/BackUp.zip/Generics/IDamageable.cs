﻿namespace Generics
{
    public interface IDamageable
    {
        void ApplyDamage(float amount);
    }
}