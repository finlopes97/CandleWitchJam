﻿namespace Generics
{
    public interface IHealth
    {
        float CurrentHealth { get; set; }
        float MaxHealth { get; set; }
        bool TakesFallDamage { get; set; }
        float FallDamageVelocityThreshold { get; set; }
        float FallDamageMultiplier { get; set; }
        bool IsInvulnerable { get; set; }

        void ApplyDamage(float amount);
    }
}