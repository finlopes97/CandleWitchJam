using UnityEngine;

namespace Generics
{
    /// <summary>
    /// Generic class for managing an entity's health and
    /// defining methods for taking damage and restoring health.
    /// </summary>
    public class Health : MonoBehaviour, IHealth
    {
        [Header("Health Settings")] 
        [SerializeField, Tooltip("Max value for entity health.")]
        private float maxHealth = 100.0f;
        [SerializeField, Tooltip("Current value for entity health.")]
        private float currentHealth;
        [SerializeField, Tooltip("Whether or not the entity takes fall damage.")]
        private bool takesFallDamage = true;
        [SerializeField, Tooltip("Velocity at which the entity takes fall damage (see Fall Speed Multiplier).")]
        private float fallDamageVelocityThreshold = 10;
        [SerializeField, Tooltip("Multiplier for calculating fall damage.")]
        private float fallDamageMultiplier = 2.0f;
        [Header("Debug Settings")] 
        [SerializeField, Tooltip("God mode.")]
        private bool isInvulnerable;

        #region Members

        public float CurrentHealth
        {
            get => currentHealth;
            set => currentHealth = Mathf.Clamp(value, 0, maxHealth);
        }

        public float MaxHealth
        {
            get => maxHealth;
            set => maxHealth = value;
        }

        public bool TakesFallDamage
        {
            get => takesFallDamage;
            set => takesFallDamage = value;
        }

        public float FallDamageVelocityThreshold
        {
            get => fallDamageVelocityThreshold;
            set => fallDamageVelocityThreshold = value;
        }

        public float FallDamageMultiplier
        {
            get => fallDamageMultiplier;
            set => fallDamageMultiplier = value;
        }

        public bool IsInvulnerable
        {
            get => isInvulnerable;
            set => isInvulnerable = value;
        }

        #endregion

        private void Awake()
        {
            currentHealth = maxHealth;
        }

        /// <summary>
        /// Damages the entity by whatever amount is specified in the
        /// method parameters.
        /// </summary>
        /// <param name="amount"></param>
        public void ApplyDamage(float amount)
        {
            CurrentHealth -= amount;
            Debug.Log($"Damage applied: {amount}, current health: {CurrentHealth}");

            if (CurrentHealth <= 0)
            {
                Debug.Log("Player has died.");
            }
        }
    }
}