﻿namespace Generics
{
    using UnityEngine;
    using UnityEngine.Events;

    /// <summary>
    /// Generic class for managing damage events on entities that can
    /// take damage
    /// </summary>
    public class Damageable : MonoBehaviour, IDamageable
    {
        // Event is invoked when damage is applied
        public UnityEvent<float> onDamaged;

        private IHealth _health;

        private void Awake()
        {
            _health = GetComponent<IHealth>();
        }
        
        /// <summary>
        /// Method to invoke event to apply damage to an entity
        /// and reduce its health
        /// </summary>
        /// <param name="amount"></param>
        public void ApplyDamage(float amount)
        {
            _health?.ApplyDamage(amount);
        }
        
        /// <summary>
        /// Applies fall damage to the entity based on the fall velocity.
        /// </summary>
        /// <param name="fallVelocity">The velocity at which the entity hit the ground.</param>
        public void ApplyFallDamage(float fallVelocity)
        {
            if (_health.IsInvulnerable || !_health.TakesFallDamage) return;

            if (fallVelocity >= _health.FallDamageVelocityThreshold)
            {
                float damageAmount = CalculateFallDamage(fallVelocity);
                ApplyDamage(damageAmount);
            }
        }

        /// <summary>
        /// Calculates the amount of damage based on the fall velocity.
        /// </summary>
        /// <param name="fallVelocity">The velocity at which the entity hit the ground.</param>
        /// <returns>The amount of damage to apply.</returns>
        private float CalculateFallDamage(float fallVelocity)
        {
            return (fallVelocity - _health.FallDamageVelocityThreshold) * _health.FallDamageMultiplier;
        }
    }
}